package com.krizz.mcgg;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText historyInput;
    private TextView resultText;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,24,32));
        getWindow().setNavigationBarColor(Color.rgb(16,24,32));

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(24));
        page.setBackgroundColor(Color.rgb(245,247,250));
        scroll.addView(page);

        TextView title = new TextView(this);
        title.setText("Prediksi Lawan MCGG");
        title.setTextSize(25);
        title.setTextColor(Color.rgb(20,30,45));
        title.setTypeface(null, 1);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Masukkan riwayat lawan secara manual untuk melihat estimasi pola berikutnya.");
        subtitle.setTextSize(14);
        subtitle.setTextColor(Color.rgb(80,90,105));
        subtitle.setPadding(0, dp(8), 0, dp(18));
        page.addView(subtitle);

        TextView label = new TextView(this);
        label.setText("Riwayat lawan (pisahkan dengan koma)");
        label.setTextSize(15);
        label.setTextColor(Color.rgb(30,40,55));
        page.addView(label);

        historyInput = new EditText(this);
        historyInput.setHint("Contoh: Mage, Fighter, Mage, Tank");
        historyInput.setMinLines(2);
        historyInput.setGravity(Gravity.TOP);
        historyInput.setTextSize(15);
        page.addView(historyInput, new LinearLayout.LayoutParams(-1, -2));

        Button predict = new Button(this);
        predict.setText("ANALISIS RIWAYAT");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(14);
        page.addView(predict, bp);

        resultText = new TextView(this);
        resultText.setText("Hasil prediksi akan muncul di sini.");
        resultText.setTextSize(16);
        resultText.setTextColor(Color.rgb(30,40,55));
        resultText.setPadding(dp(16), dp(18), dp(16), dp(18));
        resultText.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(18);
        page.addView(resultText, rp);

        TextView note = new TextView(this);
        note.setText("Catatan: ini estimasi statistik dari input manual, bukan prediksi resmi atau jaminan hasil pertandingan.");
        note.setTextSize(12);
        note.setTextColor(Color.rgb(100,110,120));
        note.setPadding(0, dp(18), 0, 0);
        page.addView(note);

        predict.setOnClickListener(v -> analyze());
        setContentView(scroll);
    }

    private void analyze() {
        String raw = historyInput.getText().toString().trim();
        if (raw.isEmpty()) {
            resultText.setText("Masukkan riwayat terlebih dahulu, contoh: Mage, Fighter, Mage.");
            return;
        }
        String[] items = raw.split("[,\\n;]+");
        java.util.LinkedHashMap<String, Integer> counts = new java.util.LinkedHashMap<>();
        int total = 0;
        for (String item : items) {
            String s = item.trim();
            if (!s.isEmpty()) {
                String key = s.substring(0, 1).toUpperCase() + s.substring(1);
                counts.put(key, counts.getOrDefault(key, 0) + 1);
                total++;
            }
        }
        if (total == 0) {
            resultText.setText("Riwayat belum terbaca. Pisahkan setiap data dengan koma.");
            return;
        }
        String best = "";
        int max = 0;
        for (java.util.Map.Entry<String, Integer> e : counts.entrySet()) {
            if (e.getValue() > max) { best = e.getKey(); max = e.getValue(); }
        }
        int percent = Math.round(100f * max / total);
        resultText.setText("Estimasi pola paling sering: " + best +
            "\\nFrekuensi: " + max + " dari " + total + " data (" + percent + "%)." +
            "\\n\\nIni hanya frekuensi riwayat yang dimasukkan, bukan kepastian lawan berikutnya.");
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
