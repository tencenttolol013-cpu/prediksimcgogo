package com.krizz.mcgg;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class OverlayService extends Service {
    WindowManager wm; View panel; WindowManager.LayoutParams params; boolean minimized=false;
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(){super.onCreate();if(!Settings.canDrawOverlays(this)){stopSelf();return;}showPanel();}
    void showPanel(){
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        params=new WindowManager.LayoutParams(dp(300),WindowManager.LayoutParams.WRAP_CONTENT,type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.RIGHT;params.x=dp(12);params.y=dp(90);
        panel=buildPanel();wm.addView(panel,params);
    }
    View buildPanel(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(14),dp(12),dp(14),dp(12));
        GradientDrawable gd=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(22,39,83),Color.rgb(48,34,104)});
        gd.setCornerRadius(dp(22));gd.setStroke(dp(1),Color.rgb(133,112,255));box.setBackground(gd);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);box.addView(head);
        TextView logo=txt("👑 Raja Gokgok",15,Color.WHITE,true);head.addView(logo,new LinearLayout.LayoutParams(0,-2,1));
        TextView mini=txt("−",24,Color.WHITE,true);mini.setGravity(Gravity.CENTER);head.addView(mini,new LinearLayout.LayoutParams(dp(32),dp(32)));
        TextView close=txt("×",24,Color.WHITE,true);close.setGravity(Gravity.CENTER);head.addView(close,new LinearLayout.LayoutParams(dp(30),dp(32)));
        View line=new View(this);line.setBackgroundColor(Color.rgb(87,102,166));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));lp.topMargin=dp(6);lp.bottomMargin=dp(9);box.addView(line,lp);
        TextView label=txt("🔮  PREDIKSI LAWAN BERIKUTNYA",11,Color.rgb(190,204,255),true);box.addView(label);
        TextView result=txt("",18,Color.WHITE,true);result.setPadding(0,dp(7),0,dp(2));box.addView(result);
        TextView pct=txt("",12,Color.rgb(135,222,255),false);box.addView(pct);
        TextView history=txt("",11,Color.rgb(197,205,230),false);history.setPadding(0,dp(8),0,0);box.addView(history);
        updateText(result,pct,history);
        mini.setOnClickListener(v->{if(minimized){result.setVisibility(View.VISIBLE);pct.setVisibility(View.VISIBLE);history.setVisibility(View.VISIBLE);label.setVisibility(View.VISIBLE);line.setVisibility(View.VISIBLE);mini.setText("−");minimized=false;}else{result.setVisibility(View.GONE);pct.setVisibility(View.GONE);history.setVisibility(View.GONE);label.setVisibility(View.GONE);line.setVisibility(View.GONE);mini.setText("+");minimized=true;}});
        close.setOnClickListener(v->stopSelf());
        head.setOnTouchListener(new View.OnTouchListener(){int sx,sy;float tx,ty;public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0){sx=params.x;sy=params.y;tx=e.getRawX();ty=e.getRawY();return true;}if(e.getAction()==2){params.x=sx+(int)(tx-e.getRawX());params.y=sy+(int)(e.getRawY()-ty);try{wm.updateViewLayout(panel,params);}catch(Exception ex){}return true;}return true;}});
        return box;
    }
    void updateText(TextView result,TextView pct,TextView history){
        android.content.SharedPreferences p=getSharedPreferences("raja",0);
        String pred=p.getString("prediction","Belum ada data");int percent=p.getInt("percent",0);
        result.setText(pred);pct.setText(percent+"% frekuensi riwayat");
        String raw=p.getString("history","");String[] items=raw.split("[,;\\n]+");StringBuilder b=new StringBuilder("Dari catatan: ");
        int n=0;for(String s:items){if(!s.trim().isEmpty()){if(n++>0)b.append(" • ");b.append(s.trim());if(n==4)break;}}
        if(n==0)b.append("buka Raja Gokgok dan masukkan riwayat");
        history.setText(b.toString());
    }
    TextView txt(String s,int size,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception e){}super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
