package com.krizz.mcgg;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.util.*;

public class MainActivity extends Activity {
    EditText history;
    TextView result, status;
    int bg=Color.rgb(8,15,37), white=Color.WHITE, muted=Color.rgb(185,198,225);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(20),dp(26),dp(20),dp(24));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(13,27,65),bg,Color.rgb(30,20,70)}));
        sc.addView(root);
        TextView brand=text("👑  Raja Gokgok",27,white,true); root.addView(brand);
        TextView sub=text("PREDIKSI LAWAN MCGG  •  BY KRIZZ",12,muted,true); sub.setPadding(0,dp(4),0,dp(20)); root.addView(sub);
        LinearLayout hero=card(); root.addView(hero);
        hero.addView(text("🔮  Prediksi Lawan Berikutnya",18,white,true));
        result=text("Masukkan riwayat lawan untuk menghitung estimasi statistik.",15,muted,false);
        result.setPadding(0,dp(12),0,dp(6)); hero.addView(result);
        root.addView(space(14));
        root.addView(text("RIWAYAT LAWAN MANUAL",12,muted,true));
        history=new EditText(this); history.setTextColor(white); history.setHintTextColor(Color.rgb(130,145,180));
        history.setHint("Contoh: Masha, Yin, Gusion, Masha"); history.setMinLines(3); history.setGravity(Gravity.TOP);
        history.setTextSize(15); history.setPadding(dp(14),dp(12),dp(14),dp(12)); history.setBackground(round(Color.rgb(24,40,78),dp(16),Color.rgb(70,91,145)));
        root.addView(history,new LinearLayout.LayoutParams(-1,-2));
        Button predict=button("ANALISIS RIWAYAT"); root.addView(predict,matchWrap());
        predict.setOnClickListener(v->analyze(true));
        Button overlay=button("✦  AKTIFKAN FLOATING OVERLAY"); root.addView(overlay,matchWrap());
        overlay.setOnClickListener(v->enableOverlay());
        status=text("Overlay belum aktif. Aktifkan izin tampil di atas aplikasi lain saat diminta.",12,muted,false);
        status.setPadding(dp(4),dp(10),dp(4),dp(8)); root.addView(status);
        LinearLayout settings=card(); root.addView(settings);
        settings.addView(text("FITUR OVERLAY",15,white,true));
        settings.addView(text("• Panel mengambang di atas game/aplikasi lain\n• Bisa digeser dan ditutup\n• Tombol mini untuk sembunyikan/perlihatkan hasil\n• Data riwayat disimpan lokal di HP",13,muted,false));
        root.addView(space(14));
        TextView foot=text("Catatan: hasil adalah estimasi dari data manual, bukan jaminan lawan berikutnya.",11,muted,false); root.addView(foot);
        setContentView(sc);
        String saved=getPreferences(0).getString("history",""); history.setText(saved);
        if(!saved.isEmpty()) analyze(false);
    }
    void analyze(boolean save){
        String raw=history.getText().toString().trim();
        if(save) getPreferences(0).edit().putString("history",raw).apply();
        getSharedPreferences("raja",0).edit().putString("history",raw).apply();
        Map<String,Integer> counts=new LinkedHashMap<>();
        for(String s:raw.split("[,;\\n]+")){s=s.trim();if(!s.isEmpty()){String k=s.substring(0,1).toUpperCase()+s.substring(1);counts.put(k,counts.getOrDefault(k,0)+1);}}
        if(counts.isEmpty()){result.setText("Masukkan beberapa nama lawan, pisahkan dengan koma.");getSharedPreferences("raja",0).edit().putString("prediction","Belum ada data").putInt("percent",0).apply();return;}
        String best="";int max=0,total=0;
        for(Map.Entry<String,Integer> e:counts.entrySet()){total+=e.getValue();if(e.getValue()>max){best=e.getKey();max=e.getValue();}}
        int pct=Math.round(100f*max/total);
        result.setText("Kandidat teratas: "+best+"\nEstimasi frekuensi: "+pct+"%  •  "+max+" dari "+total+" catatan\n\nPersentase menggambarkan riwayat yang dimasukkan, bukan probabilitas pasti.");
        getSharedPreferences("raja",0).edit().putString("prediction",best).putInt("percent",pct).putString("history",raw).apply();
    }
    void enableOverlay(){
        if(!Settings.canDrawOverlays(this)){
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
            startActivity(i); status.setText("Aktifkan izin 'Tampil di atas aplikasi lain', lalu kembali dan tekan tombol overlay lagi."); return;
        }
        analyze(true); startService(new Intent(this,OverlayService.class)); status.setText("Overlay aktif. Lu bisa pindah ke game sekarang.");
        Toast.makeText(this,"Floating overlay aktif",Toast.LENGTH_SHORT).show();
    }
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(16),dp(16),dp(16),dp(16));l.setBackground(round(Color.argb(225,26,43,83),dp(20),Color.rgb(83,94,160)));return l;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(white);b.setAllCaps(false);b.setTextSize(14);b.setBackground(round(Color.rgb(91,72,235),dp(16),Color.rgb(115,110,255)));return b;}
    GradientDrawable round(int c,int r,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);d.setStroke(dp(1),stroke);return d;}
    LinearLayout.LayoutParams matchWrap(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(12);return p;}
    View space(int h){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return v;}
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
}
