# Raja Gokgok — Prediksi Lawan MCGG
**By Krizz** · Android Java · Floating overlay

## Fitur
- UI gelap bernuansa liquid-glass / neon.
- Input manual riwayat lawan, simpan lokal.
- Estimasi frekuensi kandidat paling sering muncul.
- Floating overlay Android yang bisa digeser, diminimalkan, dan ditutup.
- Build APK otomatis dengan GitHub Actions.

## Build APK lewat HP (tanpa Android Studio)
1. Buat repository GitHub baru.
2. Upload seluruh isi ZIP ini ke root repository (bukan upload ZIP sebagai satu file).
3. Buka tab **Actions**, pilih **Build Raja Gokgok APK**, lalu **Run workflow** jika belum berjalan otomatis.
4. Setelah selesai, buka run yang hijau, cari **Artifacts**, unduh `Raja-Gokgok-debug-apk`, lalu ekstrak ZIP artifact dan instal APK.
5. Saat pertama kali mengaktifkan overlay, tekan tombol **Aktifkan Floating Overlay**, lalu izinkan **Tampil di atas aplikasi lain** di pengaturan Android. Kembali ke aplikasi dan tekan tombolnya lagi.

## Catatan
- Aplikasi meminta izin overlay Android yang harus diaktifkan manual oleh pengguna.
- Hasil hanyalah ringkasan frekuensi dari input manual, bukan prediksi resmi atau jaminan.
- APK hasil workflow adalah debug build; Android dapat meminta konfirmasi instalasi dari sumber tidak dikenal.
